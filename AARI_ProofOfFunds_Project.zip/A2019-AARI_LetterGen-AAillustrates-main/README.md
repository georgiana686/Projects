# A2019-AARI_LetterGen-AAillustrates
 Sample files from the AAillustrates episode on AARI (Automation Anywhere Robotic Interface)
